<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_Setup_MiscInterface
 *
 * @since 1.7.0.
 */
interface MAKE_Setup_MiscInterface extends MAKE_Util_ModulesInterface {}